﻿using UnityEngine;
using System.Collections;

public class Ground_children : MonoBehaviour {

	public Transform parent;
	// Use this for initialization
	void Start () {
		renderer.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
